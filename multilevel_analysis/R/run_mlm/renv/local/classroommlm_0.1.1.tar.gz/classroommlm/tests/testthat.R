library(testthat)
library(classroommlm)

test_check("classroommlm")
